/**
 * Managed beans for the JSF example applications.
 */
package com.apress.projsf2html5.jsf;
